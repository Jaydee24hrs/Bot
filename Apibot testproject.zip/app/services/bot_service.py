def generate_reply(text: str) -> str:
    # placeholder for future ML/NLP model integration or external API call
    # keep this function pure for easier testing
    return f"Bot reply: {text[::-1]}"  # silly reverse-text example
