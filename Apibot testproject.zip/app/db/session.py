from sqlmodel import create_engine, SQLModel, Session
from app.core.config import settings
from typing import Generator

engine = create_engine(settings.DATABASE_URL, echo=False)

def init_db():
    # Import models here so they are registered
    from app.models.user import User
    SQLModel.metadata.create_all(engine)

def get_session() -> Generator[Session, None, None]:
    with Session(engine) as session:
        yield session
