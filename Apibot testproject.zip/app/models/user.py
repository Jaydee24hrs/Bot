from sqlmodel import SQLModel, Field
from typing import Optional
import datetime

class UserBase(SQLModel):
    email: str
    full_name: Optional[str] = None
    is_active: bool = True

class User(UserBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    hashed_password: str
    created_at: datetime.datetime = Field(default_factory=datetime.datetime.utcnow)
