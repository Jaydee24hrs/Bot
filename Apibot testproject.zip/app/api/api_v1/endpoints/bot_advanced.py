from fastapi import APIRouter, Depends
from app.services.bot_service import generate_reply
from app.api.deps import get_current_user
from pydantic import BaseModel

router = APIRouter()

class BotIn(BaseModel):
    text: str

@router.post("/advanced")
def advanced_bot(msg: BotIn, user=Depends(get_current_user)):
    reply = generate_reply(msg.text)
    return {"reply": reply}
