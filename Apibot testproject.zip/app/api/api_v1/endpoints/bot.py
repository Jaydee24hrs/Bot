from fastapi import APIRouter, BackgroundTasks, Depends
from pydantic import BaseModel
from app.api.deps import get_current_user

router = APIRouter()

class BotMessage(BaseModel):
    text: str

def long_running_task(data: str):
    # placeholder for background processing (e.g., NLP, calling external API)
    print("Processing in background:", data)

@router.post("/reply")
def bot_reply(msg: BotMessage, background_tasks: BackgroundTasks, user=Depends(get_current_user)):
    # Simple echo with extra metadata
    background_tasks.add_task(long_running_task, msg.text)
    return {"reply": f"Echo: {msg.text}", "user": user.email}
