from fastapi.testclient import TestClient
from app.main import app
import os

client = TestClient(app)

def test_signup_and_login():
    # ensure DB created fresh file for tests
    if os.path.exists("./dev.db"):
        os.remove("./dev.db")
    resp = client.post("/api/v1/auth/signup", json={"email":"test@example.com","password":"secret","full_name":"Tester"})
    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data

    # login
    resp2 = client.post("/api/v1/auth/login", json={"email":"test@example.com","password":"secret"})
    assert resp2.status_code == 200
    data2 = resp2.json()
    assert "access_token" in data2
